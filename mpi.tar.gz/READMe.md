# NOTE ABOUT THE OUTPUT:
process 0 wil print an "nonexisting" row of -1s as its first row, as will the last process will print a -1 row as its last row. This is the represent numbers outside of their borders

# Errors and their solutions
## problem: mpicc not found
vboxuser@mydebian:~/parallel/parallel-mpi$ mpicc -g -Wall -o mpi_hello mpi_hello.c
bash: mpicc: command not found
## solution:
run 'sudo apt install openmpi-bin openmpi-common libopenmpi-dev'
